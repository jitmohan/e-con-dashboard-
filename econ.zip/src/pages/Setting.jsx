const Setting = () => {
  return <div className="title"> Setting</div>;
};

export default Setting;
