const FileManager = () => {
  return <div className="title"> File Manager</div>;
};

export default FileManager;
