import React from "react";
import Chart from "../components/Chart/Chart";
import Countrytable from "../components/table/Countrytable";


const Dashboard = () => {
  return (
    <>
  <div className="title">
    {/* hello, work is under progress...!! */}    
  </div>
  <div>
    <Chart/>
  </div>
  <div>
    <Countrytable/>
  </div>
  </>
  );
};

export default Dashboard;
