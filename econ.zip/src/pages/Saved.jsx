const Saved = () => {
  return <div className="title"> Saved</div>;
};

export default Saved;
